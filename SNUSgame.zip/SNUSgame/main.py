import time

import pygame

pygame.init()
# set a display
size_scr = pygame.display.Info()

speed = 1024 / 76
width = 1280
height = 1024
isQuit = False
display = pygame.display.set_mode((width, height))
pygame.display.set_caption("SNUSOED BETA V1")
# portal vars
x_portal = height / 1
y_portal = height / 100
# border and lvl vars
bottom_border = height / 1.249
LVL_NUMBER = 1
# fps system
clock = pygame.time.Clock()
st_FPS = 120
# draw vars
SKY_COLOR = (56, 204, 214)
GRASS_COLOR = (36, 145, 40)
tile_size = int(height / 5)
# LVL_DATA and class of World
LVL_DATA = [
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 0],
    [0, 0, 0, 1, 0, 0],
    [0, 0, 1, 0, 0, 0],
    [2, 2, 2, 2, 2, 2, 2]

]


def render_text(TEXT, X, Y, FONT_COLOR, FONT_TYPE, FONT_SIZE):
    font = pygame.font.Font(FONT_TYPE, FONT_SIZE)
    text = font.render(TEXT, True, FONT_COLOR)
    display.blit(text, (X, Y))


class Button:
    def __init__(self, butt_width, butt_height):
        self.width = butt_width
        self.height = butt_height
        self.active_color = (242, 207, 29)
        self.inactive_color = (214, 201, 133)

    def draw(self, x, y):
        self.y = y
        self.x = x

    def start_action(self):
        global runMenu
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()

        if self.x < mouse[0] < self.x + self.width and self.y < mouse[1] < self.y + self.height and click == (1, 0, 0):
            game_loop(True)
            runMenu = False

    def quit_action(self):
        global isQuit
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()

        if self.x < mouse[0] < self.x + self.width and self.y < mouse[1] < self.y + self.height and click == (1, 0, 0):
            pygame.quit()
            isQuit = True


class World:
    def __init__(self, data):
        self.tile_list = []
        image_platform = pygame.image.load('assets/images/World/platform.png')
        image_grass = pygame.image.load('assets/images/World/grass.png')
        # make rect
        row_count = 0
        for row in data:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = pygame.transform.scale(image_platform, (int(tile_size / 3), int(tile_size / 3)))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    self.x = img_rect.x
                    self.y = img_rect.y
                    tile = (img, img_rect)
                    self.tile_list.append(tile)

                if tile == 2:
                    img = pygame.transform.scale(image_grass, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                col_count += 1
            row_count += 1

    def draw(self):
        for tile in self.tile_list:
            display.blit(tile[0], tile[1])
            # pygame.draw.rect(display, (255, 255, 255), tile[1], 2)

    def draw_cloud(self):
        cloud1 = pygame.Rect(10, 100, 200, 30)
        cloud2 = pygame.Rect(250, 100, 200, 30)
        cloud3 = pygame.Rect(500, 30, 200, 30)
        cloud4 = pygame.Rect(750, 80, 200, 30)
        cloud5 = pygame.Rect(950, 120, 200, 30)

        pygame.draw.rect(display, (255, 255, 255), cloud1)
        pygame.draw.rect(display, (255, 255, 255), cloud2)
        pygame.draw.rect(display, (255, 255, 255), cloud3)
        pygame.draw.rect(display, (255, 255, 255), cloud4)
        pygame.draw.rect(display, (255, 255, 255), cloud5)

    def draw_snus(self, x, y):
        img = pygame.image.load('assets/images/World/SNUS.png')
        self.img_snus = pygame.transform.scale(img, (tile_size, tile_size))
        self.snus_rect = self.img_snus.get_rect()
        self.snus_rect.x = x
        self.snus_rect.y = y
        self.snus_width = self.img_snus.get_width()
        self.snus_height = self.img_snus.get_height()

        display.blit(self.img_snus, self.snus_rect)


# init the world class
world = World(LVL_DATA)


# Player class
class Player:
    def __init__(self, x, y):
        img = pygame.image.load('assets/images/entity/player/player.png')
        self.img_player = pygame.transform.scale(img, (tile_size, tile_size))
        self.rect = self.img_player.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.width = self.img_player.get_width()
        self.height = self.img_player.get_height()
        self.width = self.img_player.get_width()
        self.height = self.img_player.get_height()
        self.jumpCount = 0
        self.IS_JUMP = 0

    # update func
    def update(self):
        global speed
        dx = 0
        dy = 0
        key = pygame.key.get_pressed()

        # to right move
        if key[pygame.K_d] and not self.rect.x == height / 152:
            dx += speed

        # to left move
        if key[pygame.K_a]:
            dx -= speed

        # Jump release
        if key[pygame.K_SPACE] and self.IS_JUMP is False:
            self.IS_JUMP = True
            self.jumpCount = -height / 65
        # add gravity
        self.jumpCount += 1
        if self.jumpCount > height / 100:
            self.jumpCount = height / 100
        dy += self.jumpCount
        self.IS_JUMP = False
        # add collisions
        for tile in world.tile_list:
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0

            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                if self.jumpCount < 0:
                    dy = tile[1].bottom - self.rect.top
                elif self.jumpCount >= 0:
                    dy = tile[1].top - self.rect.bottom

        # update the cords
        if player.rect.x == width + width / 100:
            player.rect.x = 0
        player.rect.x += dx
        player.rect.y += dy
        if self.rect.bottom > bottom_border:
            self.rect.bottom = bottom_border
        if self.rect.top < -height / 200:
            self.rect.top = -height / 200
        # draw the player
        display.blit(self.img_player, self.rect)
        # pygame.draw.rect(display, (255, 255, 255), self.rect, 2)

    def snusik(self, x, y):
        img = pygame.image.load('assets/images/World/SNUS.png')
        self.img_snus = pygame.transform.scale(img, (int(height / 20), int(height / 20)))
        self.rect_snus = self.img_player.get_rect()
        self.rect_snus.x = x
        self.rect_snus.y = y
        self.width = self.img_player.get_width()
        self.height = self.img_player.get_height()
        self.width = self.img_player.get_width()
        self.height = self.img_player.get_height()
        display.blit(self.img_snus, self.rect_snus)

        if self.rect_snus.colliderect(self.rect.x, self.rect.y, self.height, self.width) and LVL_NUMBER == 3:
            self.rect.x = height / 100
            self.rect.y = height / 2
        if self.rect_snus.colliderect(self.rect.x, self.rect.y, self.height, self.width) and LVL_NUMBER == 4:
            self.rect.x = height / 200
            self.rect.y = height / 3
        if self.rect_snus.colliderect(self.rect.x, self.rect.y, self.height, self.width) and LVL_NUMBER == 6:
            self.rect.x = height / 100
            self.rect.y = height / 100

    # create the portal with player move
    def portal(self, x, y):
        global bottom_border
        global LVL_NUMBER
        # make x_portal and y_portal the global vars
        global x_portal
        global y_portal
        # init & load portal image
        image_portal = pygame.image.load('assets/images/World/portal.png')
        img = pygame.transform.scale(image_portal,
                                     (int(tile_size / 2), int(tile_size)))
        img_rect = img.get_rect()
        img_rect.x = x
        img_rect.y = y
        bottom_border2 = pygame.Rect(0, bottom_border - height / 100, width, height / 10)
        if bottom_border2.colliderect(self.rect.x, self.rect.bottom, bottom_border2.width,
                                      bottom_border2.height) and LVL_NUMBER == 2:
            self.rect.x = height / 10
            self.rect.y = height / 2
        if bottom_border2.colliderect(self.rect.x, self.rect.bottom, bottom_border2.width,
                                      bottom_border2.height) and LVL_NUMBER == 3:
            self.rect.x = width / width
            self.rect.y = height / 3
        if bottom_border2.colliderect(self.rect.x, self.rect.bottom, bottom_border2.width,
                                      bottom_border2.height) and LVL_NUMBER == 4:
            self.rect.x = height / 20
            self.rect.y = height / 3
        if bottom_border2.colliderect(self.rect.x, self.rect.bottom, bottom_border2.width,
                                      bottom_border2.height) and LVL_NUMBER == 5:
            self.rect.x = height / 20
            self.rect.y = height / 10 * 3
        if bottom_border2.colliderect(self.rect.x, self.rect.bottom, bottom_border2.width,
                                      bottom_border2.height) and LVL_NUMBER == 6:
            self.rect.x = height / 100
            self.rect.y = height / 100

        if LVL_NUMBER == 2:
            top_border_2 = pygame.Rect(0, 0, width, height / 10 * 3.6)

            pygame.draw.rect(display, (242, 12, 12), top_border_2)
            if top_border_2.colliderect(self.rect.x, self.rect.y, self.rect.width, self.rect.height):
                self.rect.x = height / 10
                self.rect.y = height / 2
        if LVL_NUMBER == 3:
            top_border_3 = pygame.Rect(0, 0, width, height / 6)
            pygame.draw.rect(display, (242, 12, 12), top_border_3)

            self.snusik(width / 2 - height / 100 * 2, height / 10 * 5.5)

            if top_border_3.colliderect(self.rect.x, self.rect.y, self.rect.width, self.rect.height):
                self.rect.x = height / height
                self.rect.y = height / 3

        if LVL_NUMBER == 4:
            top_border_4 = pygame.Rect(0, 0, width, height / 5)
            pygame.draw.rect(display, (242, 12, 12), top_border_4)

            self.snusik(width / 2 - height / 50, height / 5.5)
            self.snusik(width - height / 10 * 2.5, height / 5.5)

            if top_border_4.colliderect(self.rect.x, self.rect.y, self.rect.width, self.rect.height):
                self.rect.x = height / height
                self.rect.y = height / 3

        if LVL_NUMBER == 5:
            top_border_5 = pygame.Rect(0, 0, width, 250)
            pygame.draw.rect(display, (242, 12, 12), top_border_5)
            if top_border_5.colliderect(self.rect.x, self.rect.y, self.rect.width, self.rect.height):
                self.rect.x = 100
                self.rect.y = 300
        if LVL_NUMBER == 6:
            self.snusik(405, 80)

        # check the portal colliderect with a player
        if img_rect.colliderect(self.rect.right, self.rect.y, (int(tile_size / 2)), int(tile_size)):
            global LVL_DATA
            global world

            # update the lvl data
            # update the lvl number
            LVL_NUMBER += 1
            # update player & portal coordinates
            if LVL_NUMBER == 2:
                LVL_DATA = [
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 1, 0, 1, 0, 1],
                    [2, 2, 2, 2, 2, 2, 2]

                ]
                self.rect.x = 100
                self.rect.y = height / 2

                x_portal = width / 1.1
                y_portal = height / 2.5

                # init updated lvl data
                world = World(LVL_DATA)
            if LVL_NUMBER == 3:
                LVL_DATA = [
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 1, 0, 0],
                    [1, 0, 0, 0, 0, 1],
                    [2, 2, 2, 2, 2, 2, 2]

                ]

                self.rect.x = 1
                self.rect.y = height / 3

                x_portal = width / 1.1
                y_portal = height / 2.5

                # init updated lvl data
                world = World(LVL_DATA)
            if LVL_NUMBER == 4:
                LVL_DATA = [
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 1, 0, 1],
                    [0, 1, 0, 0, 0, 0],
                    [2, 2, 2, 2, 2, 2, 2]

                ]

                self.rect.x = 0.1
                self.rect.y = height / 3

                x_portal = width / 1.1
                y_portal = height / 3.5

                # init updated lvl data
                world = World(LVL_DATA)

            if LVL_NUMBER == 5:
                LVL_DATA = [
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 1, 0, 1, 0],
                    [0, 0, 0, 0, 0, 0],
                    [2, 2, 2, 2, 2, 2, 2]

                ]

                self.rect.x = 100
                self.rect.y = 300

                x_portal = width / 1.1
                y_portal = height / 2.5

                # init updated lvl data
                world = World(LVL_DATA)
            if LVL_NUMBER == 6:
                LVL_DATA = [
                    [0, 0, 0, 0, 0, 0],
                    [1, 0, 1, 0, 1, 0],
                    [0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0],
                    [2, 2, 2, 2, 2, 2, 2]

                ]

                self.rect.x = 10
                self.rect.y = 10

                x_portal = width / 1.1
                y_portal = 50

                # init updated lvl data
                world = World(LVL_DATA)
        # pygame.draw.rect(display, (255, 255, 255), img_rect, 2)
        # draw image to screen
        display.blit(img, img_rect)
        # pygame.draw.rect(display, (255, 255, 255), bottom_border2, 2)

    def borders(self):
        right_border = pygame.Rect(height + height / 4.2, 0, height / 100, height)
        left_border = pygame.Rect(height / 152, 0, height / 100, height)

        # pygame.draw.rect(display, (255, 255, 255), right_border, 2)
        # pygame.draw.rect(display, (255, 255, 255), left_border, 2)

        if left_border.colliderect(self.rect.right, height / 1.249, left_border.width, left_border.height):
            self.rect.x = height / 152
        if right_border.colliderect(self.rect.right, height / 1.249, right_border.width, right_border.height):
            self.rect.x = height - height / 4.2


# player
px = 1
py = height / 2 + height / 7.25
player = Player(1, height / 2)


def game_loop(Run):
    # game loop
    while Run:
        display.fill(SKY_COLOR)
        clock.tick(st_FPS)
        if isQuit is True:
            pygame.quit()
        world.draw()
        player.borders()
        player.portal(x_portal, y_portal)
        world.draw_cloud()
        player.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Run = False
        pygame.display.update()


runMenu = True
while runMenu:
    display.fill((255, 255, 255))
    bg = pygame.image.load('assets/images/Menu.png')
    quit_button = Button(902, 586)
    start_button = Button(897, 454)

    start_button.draw(303, 354)
    quit_button.draw(307, 486)
    start_button.start_action()
    quit_button.quit_action()

    display.blit(bg, (0, 0))

    for event2 in pygame.event.get():
        if event2.type == pygame.QUIT:
            runMenu = False
    pygame.display.update()
pygame.quit()
